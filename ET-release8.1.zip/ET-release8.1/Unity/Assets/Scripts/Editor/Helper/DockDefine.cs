using System;
using System.Collections.Generic;

namespace ET
{
    public static class DockDefine
    {
        public static Type[] Types = { typeof (BuildEditor), typeof (ServerCommandLineEditor) };
    }
}