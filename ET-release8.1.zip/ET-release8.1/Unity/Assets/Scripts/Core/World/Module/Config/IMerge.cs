﻿namespace ET
{
    public interface IMerge
    {
        void Merge(object o);
    }
}