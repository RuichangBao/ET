﻿namespace ET
{
    public class CodeAttribute: BaseAttribute
    {

    }
}