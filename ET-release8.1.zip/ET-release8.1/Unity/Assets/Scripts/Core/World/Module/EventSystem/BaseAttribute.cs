﻿using System;

namespace ET
{
	[AttributeUsage(AttributeTargets.Class)]
	[EnableClass]
	public class BaseAttribute: Attribute
	{
	}
}