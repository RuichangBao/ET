﻿namespace ET
{
	/// <summary>
	/// 每个Config的基类
	/// </summary>
	public interface IConfig
	{
		int Id { get; set; }
	}
}