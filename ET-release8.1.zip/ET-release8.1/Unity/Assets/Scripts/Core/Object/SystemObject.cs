﻿namespace ET
{
    public abstract class SystemObject: Object
    {

    }
}