﻿namespace ET
{
    public abstract class HandlerObject: Object
    {

    }
}