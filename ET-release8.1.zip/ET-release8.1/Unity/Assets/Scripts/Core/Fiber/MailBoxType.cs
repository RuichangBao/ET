﻿namespace ET
{
    public enum MailBoxType
    {
        OrderedMessage = 1,
        UnOrderedMessage,
        GateSession,
    }
}