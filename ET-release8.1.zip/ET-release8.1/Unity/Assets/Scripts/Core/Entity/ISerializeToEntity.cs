﻿namespace ET
{
	public interface ISerializeToEntity
	{
	}
}