﻿namespace ET
{
    public interface IScene
    {
        Fiber Fiber { get; set; }
        SceneType SceneType { get; set; }
    }
}