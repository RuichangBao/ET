﻿using System;

namespace ET
{
	[AttributeUsage(AttributeTargets.Class | AttributeTargets.Method)]
	public class EntitySystemAttribute: BaseAttribute
	{
	}
}