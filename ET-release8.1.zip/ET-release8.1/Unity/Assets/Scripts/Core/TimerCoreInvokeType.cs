﻿namespace ET
{
    [UniqueId(0, 100)]
    public static class TimerCoreInvokeType
    {
        public const int CoroutineTimeout = 1;
    }
}