﻿namespace ET.Server
{
    public static partial class AOISeeCheckHelper
    {
        public static bool IsCanSee(AOIEntity a, AOIEntity b)
        {
            return true;
        }
    }
}