namespace ET.Generator;

public static class DiagnosticCategories
{
    public const string Generator = "ETGeneratorAnalyzers";
}