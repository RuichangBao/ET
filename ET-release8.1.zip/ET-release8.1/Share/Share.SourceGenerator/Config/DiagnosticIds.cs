namespace ET.Generator;

public static class DiagnosticIds
{
    public const string ETSystemMethodIsInStaticPartialClassRuleId = "ET1001";
}