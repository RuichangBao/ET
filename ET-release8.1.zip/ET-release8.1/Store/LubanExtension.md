# ET8-Luban
基于ET8.1集成了功能更完善的Luban(新版)配置工具，导出时支持自定义数据校验，为上线项目配置的数据安全提供了足够的保障。

**使用方式**:点击'ET-BuildTool-ExcelExporter'，实际开发时建议自行扩展成按快捷键调用ToolsEditor.ExcelExporter()

**项目链接**:[ET8-Luban](https://github.com/EP-Toushirou/ET8-Luban)