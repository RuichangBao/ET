# BundleMaster
<br/> Unity资源加载大师(纯代码ET框架集成用)</br>

<br/>Github下载地址: https://github.com/mister91jiao/BundleMaster</br>
<br/>网站地址: https://www.unitybundlemaster.com</br>
<br/>视频教程: https://www.bilibili.com/video/BV19341177Ek</br>
<br/>QQ讨论群: 787652036</br>
