namespace ET.Server
{
    [ComponentOf(typeof(Scene))]
    public class RoomManagerComponent: Entity, IAwake
    {

    }
}