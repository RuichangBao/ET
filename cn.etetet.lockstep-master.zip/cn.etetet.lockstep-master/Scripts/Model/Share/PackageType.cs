namespace ET
{
    public static partial class PackageType
    {
        public const int LockStep = 11;
    }
}
