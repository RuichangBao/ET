﻿namespace ET.Client
{
    public struct LSSceneChangeStart
    {
        public Room Room;
    }
    
    public struct LSSceneInitFinish
    {
    }
    
    public struct AfterCreateClientScene
    {
    }
    
    public struct AfterCreateCurrentScene
    {
    }

    public struct AppStartInitFinish
    {
    }

    public struct EnterMapFinish
    {
        
    }
}