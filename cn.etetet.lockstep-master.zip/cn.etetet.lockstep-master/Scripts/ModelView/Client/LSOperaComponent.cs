namespace ET
{
    [ComponentOf(typeof(Room))]
    public class LSOperaComponent: Entity, IAwake, IUpdate
    {
    }
}