﻿using System;
using System.Collections.Generic;

namespace ET.Client
{
    public static partial class UIType
    {
	    public const string UILSLogin = "UILSLogin";
	    public const string UILSLobby = "UILSLobby";
		public const string UILSRoom = "UILSRoom";
    }
}