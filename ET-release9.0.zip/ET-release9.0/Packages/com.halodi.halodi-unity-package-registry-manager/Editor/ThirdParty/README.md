# Third party libraries

To avoid conflicts between packages all third party managed DLL's are prefixed with "860BB79D", which is the CRC32 hash of "com.halodi.halodi-unity-package-creator".

Due to the 260 character limit on windows paths, we avoid prefixing the DLL names with "com.halodi.halodi-unity-package-reigstry-manager"


## NewtonSoft JSON

https://www.newtonsoft.com/json
License: MIT (see LICENSE.Newtonsoft.Json) 

## SharpZipLib

https://github.com/icsharpcode/SharpZipLib
License: MIT 

## Tomlyn

https://github.com/xoofx/Tomlyn
License: BSD-2-Clause (see LICENSE.Tomlyn)
