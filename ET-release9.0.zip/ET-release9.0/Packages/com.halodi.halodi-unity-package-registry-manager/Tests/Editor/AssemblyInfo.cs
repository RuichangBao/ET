﻿using System.Reflection;

[assembly: AssemblyTitle("com.halodi.halodi-unity-package-registry-manager.Editor.Tests")]